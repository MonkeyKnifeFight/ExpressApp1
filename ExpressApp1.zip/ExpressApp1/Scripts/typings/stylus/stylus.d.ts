﻿declare module "stylus" {
    function middleware(dir: string);
}