function list(req, res) {
    res.send("respond with a resource");
}
exports.list = list;
;
//# sourceMappingURL=user.js.map